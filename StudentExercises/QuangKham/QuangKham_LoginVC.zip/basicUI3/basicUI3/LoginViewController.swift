//
//  LoginViewController.swift
//  basicUI3
//
//  Created by Quang Kham on 8/8/18.
//  Copyright © 2018 Quang Kham. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    let margin:CGFloat = 20
    var topMargin:CGFloat = 20
    var width:CGFloat = 0
    var height:CGFloat = 0
    var uiHeight:CGFloat = 50
    var uiVgap:CGFloat = 10
    var mode:Int = 0

    
    override func viewDidLoad() {
        super.viewDidLoad()
        //initialise
        width = view.frame.size.width
        height = view.frame.size.height
        topMargin = height / 10
        
        let lowerLayer = UIView(frame: view.frame)
        let upperLayer = UIView(frame: view.frame)
        
        
        
        let bgImageView = UIImageView()
        bgImageView.frame.size = view.frame.size
        bgImageView .image = UIImage(named:"bgPic")
        bgImageView.contentMode = .scaleAspectFill
        //view.backgroundColor = UIColor.lightGray
        lowerLayer.addSubview(bgImageView)
        
        
        let imageView = UIImageView()
        
        imageView.center = CGPoint(x: width / 3, y: topMargin)
        imageView.frame.size = CGSize(width: 100, height: 100 )
        imageView.layer.cornerRadius = imageView.frame.size.width / 2
        imageView.image = UIImage(named: "guitar")
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        upperLayer.addSubview(imageView)
        
        
        
        
        

        let userNameTextField = UITextField()
        userNameTextField.frame = CGRect(x: margin , y: imageView.frame.origin.y * 3 + uiHeight + uiVgap, width: width - margin * 2, height: uiHeight)
        userNameTextField.borderStyle = .roundedRect
        userNameTextField.placeholder = "Enter User Name"
        upperLayer.addSubview(userNameTextField)
        
        let userNameErrorLabel = UILabel()
        userNameErrorLabel.frame.size = CGSize(width: width - margin, height: uiHeight)
        userNameErrorLabel.frame.origin.y = userNameTextField.frame.origin.y + uiHeight + uiVgap
        userNameErrorLabel.frame.origin.x = userNameTextField.frame.origin.x
        userNameErrorLabel.textAlignment = .center
        userNameErrorLabel.text = "Invalid email format"
        userNameErrorLabel.textColor = UIColor.darkGray
        upperLayer.addSubview(userNameErrorLabel)
        
        
        let pwdTextField = UITextField()
        pwdTextField.frame = CGRect(x: userNameErrorLabel.frame.origin.x  , y: userNameErrorLabel.frame.origin.y + uiHeight + uiVgap, width: width - margin * 2 , height: uiHeight)
        pwdTextField.borderStyle = .roundedRect
        pwdTextField.placeholder = "Enter Password"
        upperLayer.addSubview(pwdTextField)
        
        
        let pwdErrorLabel = UILabel()
        pwdErrorLabel.frame = CGRect(x: pwdTextField.frame.origin.x, y: pwdTextField.frame.origin.y + uiHeight + uiVgap, width: width - margin , height: uiHeight)
        pwdErrorLabel.textAlignment = .center
        pwdErrorLabel.text = "Invalid password format"
        pwdErrorLabel.textColor = UIColor.darkGray
        upperLayer.addSubview(pwdErrorLabel)
        
        
        let loginBtn = UIButton()
        loginBtn.center = CGPoint(x: width * 1/3, y: pwdErrorLabel.frame.origin.y + uiHeight + uiVgap)
        loginBtn.frame.size = CGSize(width: width * 1/3, height: uiHeight)
        loginBtn.backgroundColor = UIColor.purple
        loginBtn.alpha = 0.8
        loginBtn.layer.cornerRadius = 8.0
        loginBtn.layer.borderColor = UIColor.white.cgColor
        loginBtn.setTitle("Log In", for: .normal)
        upperLayer.addSubview(loginBtn)
    
        
        let changeModeBtn = UIButton()
        changeModeBtn.center = CGPoint(x: loginBtn.frame.origin.x -
            margin, y: height * 5/6 + uiHeight)
        changeModeBtn.frame.size = CGSize(width: width / 2, height: uiHeight)
        changeModeBtn.setTitleColor(UIColor.white, for: .normal)
        
        changeModeBtn.setTitle("New User? Sign UP", for: .normal)
            upperLayer.addSubview(changeModeBtn)
        
        view.addSubview(lowerLayer)
        view.addSubview(upperLayer)
        
      
        
      
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
