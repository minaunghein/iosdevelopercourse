//
//  ViewController.swift
//  basicUI3
//
//  Created by Quang Kham on 8/8/18.
//  Copyright © 2018 Quang Kham. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var mode:Int = 0
    

    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var userNameErrorLabel: UILabel!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var passwordErrorLabel: UILabel!
    @IBOutlet weak var loginSignupButton: UIButton!
    @IBOutlet weak var changeModeButton: UIButton!
    
    
    @IBAction func loginSignUP(_ sender: UIButton) {
        
        
    }
    
    
    @IBAction func changeMode(_ sender: UIButton) {
        if mode == 0{
            mode = 1
            loginSignupButton.setTitle("SignUP", for: .normal)
            changeModeButton.setTitle("Already register?Login", for: .normal)
        
    }
        else if mode == 1{
            mode = 0
            loginSignupButton.setTitle("Login", for: .normal)
            changeModeButton.setTitle("New User? Sign UP", for: .normal)
            
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        loginSignupButton.layer.cornerRadius = 7.0
        loginSignupButton.layer.borderWidth = 2
        loginSignupButton.layer.borderColor = UIColor.blue.cgColor
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

