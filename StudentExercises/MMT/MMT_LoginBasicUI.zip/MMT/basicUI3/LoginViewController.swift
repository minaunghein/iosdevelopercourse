//
//  LoginViewController.swift
//  basicUI3
//
//  Created by Franz on 8/8/18.
//  Copyright © 2018 Franz. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    let margin:CGFloat = 60.0
    var topMargin:CGFloat = 40.0
    var width:CGFloat = 0
    var height:CGFloat = 0
    var uiHeight:CGFloat = 50
    var uiVgap:CGFloat = 10
    
    var usernameTextField: UITextField!
    var usernameErrorLabel: UILabel!
    
    var passwordTextField: UITextField!
    var pwErrorLabel: UILabel!
    
    var loginSignupBtn: UIButton!
    var modeBtn: UIButton!
    
    var modebtnclick = 0
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        setup()
        
    }
    
    func setup() {
        
        //Initialize
        width = view.frame.size.width
        height = view.frame.size.height
        topMargin = height / 10
        
        
        //Background Image
        let backgroundImageView = UIImageView()
        backgroundImageView.image = UIImage(named: "bitmap")
        backgroundImageView.contentMode = .scaleAspectFill
        backgroundImageView.frame = CGRect(x: 0, y: 0, width: width, height: height)
        view.addSubview(backgroundImageView)
        
        
        //Construct TextField & Label
        //Username
        usernameTextField = UITextField()
        usernameTextField.frame = CGRect(x: margin, y: topMargin, width: width - margin * 2, height: uiHeight)
        
        usernameTextField.borderStyle = UITextBorderStyle.none

        usernameTextField.placeholder = "Enter Email"
        
        usernameTextField.layer.masksToBounds = false
        usernameTextField.layer.shadowColor = UIColor.gray.cgColor
        usernameTextField.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        usernameTextField.layer.shadowOpacity = 1.0
        usernameTextField.layer.shadowRadius = 0.0
        
        view.addSubview(usernameTextField)
        
        
        usernameErrorLabel = UILabel()
        usernameErrorLabel.frame.size = CGSize(width: width, height: uiHeight)
        usernameErrorLabel.frame.origin.y = usernameTextField.frame.origin.y + uiHeight + uiVgap
        
        usernameErrorLabel.textAlignment = .center
        usernameErrorLabel.text = ""
        usernameErrorLabel.textColor = .red
        view.addSubview(usernameErrorLabel)
        
        //Password
        passwordTextField = UITextField()
        passwordTextField.frame = CGRect(x: margin, y: 180, width: width - margin * 2, height: uiHeight)
        passwordTextField.borderStyle = .none
        passwordTextField.placeholder = "Enter Password"
        passwordTextField.isSecureTextEntry = true
        
        
        passwordTextField.layer.masksToBounds = false
        passwordTextField.layer.shadowColor = UIColor.gray.cgColor
        passwordTextField.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        passwordTextField.layer.shadowOpacity = 1.0
        passwordTextField.layer.shadowRadius = 0.0
        
        
        view.addSubview(passwordTextField)

        pwErrorLabel = UILabel()
        pwErrorLabel.frame.size = CGSize(width: width, height: uiHeight)
        pwErrorLabel.frame.origin.y = passwordTextField.frame.origin.y + uiHeight + uiVgap
        
        pwErrorLabel.textAlignment = .center
        pwErrorLabel.text = ""
        pwErrorLabel.textColor = .red
        view.addSubview(pwErrorLabel)
        
        passwordTextField.isHidden = true
        
        
        usernameTextField.leftView =  UIImageView(image: UIImage(named:"user"))
        usernameTextField.leftViewMode = .always
        passwordTextField.leftView =  UIImageView(image: UIImage(named:"lock"))
        passwordTextField.leftViewMode = .always
        
        //Construct Login button
        loginSignupBtn = UIButton()
        loginSignupBtn.frame = CGRect(x: 60.0, y: height - 400, width: width - margin * 2, height: 60)
        loginSignupBtn.backgroundColor = UIColor.darkGray
        loginSignupBtn.layer.cornerRadius = 30
        loginSignupBtn.setTitle("Log In", for: .normal)
        loginSignupBtn.setTitleColor(.white, for: .normal)
        loginSignupBtn.addTarget(self, action: #selector(checkLogin), for: .touchUpInside)
        loginSignupBtn.showsTouchWhenHighlighted = true
        view.addSubview(loginSignupBtn)

        //Construct Mode button
        modeBtn = UIButton()
        modeBtn.frame = CGRect(x: 60.0, y: height - 120, width: width - margin * 2, height: 20)
        modeBtn.setTitle("New User? Sign Up", for: .normal)
        modeBtn.setTitleColor(.blue, for: .normal)
        modeBtn.addTarget(self, action: #selector(checkMode), for: .touchUpInside)
        view.addSubview(modeBtn)
        
        usernameTextField.delegate = self
        passwordTextField.delegate = self
        
        
        
    


    }
    //Add Action
    @objc func checkLogin(_ sender: UIButton) {
        
        checkFields()
    }
    @objc func checkMode(_ sender: UIButton) {
      
        if modebtnclick == 0  {
            modebtnclick = 1
            loginSignupBtn.setTitle("Sign Up", for: .normal)
            modeBtn.setTitle("Already Register? Log In.", for: .normal)
        } else if modebtnclick == 1 {
            modebtnclick = 0
            loginSignupBtn.setTitle("Log In", for: .normal)
            modeBtn.setTitle("New User? Sign Up.", for: .normal)
        }
        
        checkFields()
    }
    func checkFields() {
        
        
        guard let email =  usernameTextField.text, email != ""  else {
            usernameErrorLabel.text =  "Invalid email"
            return
        }
        usernameErrorLabel.text  = ""
        guard let password =  passwordTextField.text, password != "" else {
            pwErrorLabel.text =  "Invalid password"
            return
        }
        pwErrorLabel.text = ""
//        print("Proceed to login")
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField  == usernameTextField && passwordTextField.text == "" {
            passwordTextField.isHidden = false
            passwordTextField.becomeFirstResponder()
        }else {
            
            textField.resignFirstResponder()
        }
        return true
    }

}
