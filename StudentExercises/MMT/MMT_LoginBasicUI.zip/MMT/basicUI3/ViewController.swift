//
//  ViewController.swift
//  basicUI3
//
//  Created by Franz on 8/8/18.
//  Copyright © 2018 Franz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var mode = 0
    
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passWordTextField: UITextField!
    @IBOutlet weak var errorMsg1Label: UILabel!
    @IBOutlet weak var errorMsg2Label: UILabel!
    @IBOutlet weak var loginSignupbtn: UIButton!
    @IBOutlet weak var changeModeBtn: UIButton!
    
    @IBAction func loginSignup(_ sender: UIButton) {
        
        
    }
    
    
    @IBAction func changeMode(_ sender: UIButton) {
    
        if mode == 0 {
            mode = 1
            loginSignupbtn.setTitle("Sign Up", for: .normal)
            changeModeBtn.setTitle("Already Register? Log In.", for: .normal)
        } else if mode == 1 {
            mode = 0
            loginSignupbtn.setTitle("Log In", for: .normal)
            changeModeBtn.setTitle("New User? Sign Up.", for: .normal)
        }
    
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loginSignupbtn.layer.cornerRadius = 7.0
        loginSignupbtn.layer.borderWidth = 2
        loginSignupbtn.layer.borderColor = UIColor.green.cgColor
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

