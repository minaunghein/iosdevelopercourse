//
//  ViewController.swift
//  BasicUI3
//
//  Created by Analika Khin on 8/8/18.
//  Copyright © 2018 Analika Khin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var mode:Int = 1
    
    @IBOutlet weak var UserNameTextField: UITextField!
    @IBOutlet weak var UserNameErrorLabel: UILabel!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var PsErrorLabel: UILabel!
    @IBOutlet weak var LogInSignUpbtn: UIButton!
    @IBOutlet weak var changeModebtn: UIButton!
    
    
    @IBAction func LoginSignup(_ sender: UIButton) {
        
    }
    
    
    @IBAction func changeMode(_ sender: UIButton) {
        
        if mode == 0 {
            mode = 1
            LogInSignUpbtn.setTitle("SignUp", for: .normal)
            changeModebtn.setTitle("Already Register? LogIn", for: .normal)
        }
        else if mode == 1 {
            mode = 0
            LogInSignUpbtn.setTitle("LogIn", for: .normal)
            changeModebtn.setTitle("New User? SignUp", for: .normal)
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LogInSignUpbtn.layer.cornerRadius = 8.0
        LogInSignUpbtn.layer.borderWidth = 2
        LogInSignUpbtn.layer.borderColor = UIColor.gray.cgColor
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

