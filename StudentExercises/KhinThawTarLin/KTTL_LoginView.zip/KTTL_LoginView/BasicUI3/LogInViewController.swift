//
//  LogInViewController.swift
//  BasicUI3
//
//  Created by Analika Khin on 8/8/18.
//  Copyright © 2018 Analika Khin. All rights reserved.
//

import UIKit

class LogInViewController: UIViewController {
    
    let margin:CGFloat = 20.0
    var topMargin:CGFloat = 40.0
    var width:CGFloat = 0
    var height:CGFloat = 0
    var uiHeight:CGFloat = 60.0
    var uiVgap:CGFloat = 60.0
    //var bottomMargin:CGFloat = -40.0

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.cyan
        print(self.view.frame.width, self.view.frame.height)

        // Construct TextFields & Label
        
        width = view.frame.size.width
        height = view.frame.size.height
        topMargin = height/10
        
        let UserNameTextField = UITextField()
        UserNameTextField.frame = CGRect (x: margin, y: topMargin, width: width - margin * 2, height: 60)
        UserNameTextField.placeholder = "Enter UserName or Email"
        UserNameTextField.borderStyle = .roundedRect
        view.addSubview(UserNameTextField)
        
        let UserNameErrorLabel = UILabel()
        UserNameErrorLabel.frame.size = CGSize (width: width, height: uiHeight)
        UserNameErrorLabel.frame.origin.y = UserNameErrorLabel.frame.origin.y + uiHeight + uiVgap
        UserNameErrorLabel.frame.origin.x = UserNameTextField.frame.origin.x
        //UserNameErrorLabel.textAlignment = .center
        UserNameErrorLabel.textColor = .red
        UserNameErrorLabel.text = "**Invalid UserName"
        view.addSubview(UserNameErrorLabel)
        
        let PasswordTextField = UITextField ()
        PasswordTextField.frame = CGRect (x: 20, y: topMargin * 3, width: width - margin * 2, height: 60)
        PasswordTextField.placeholder = "Enter Password"
        PasswordTextField.isSecureTextEntry = true
        PasswordTextField.borderStyle = .roundedRect
        view.addSubview(PasswordTextField)
        
        let PasswordErrorLabel = UILabel ()
        PasswordErrorLabel.frame.size = CGSize (width: width + 2, height: uiHeight * 6)
        PasswordErrorLabel.frame.origin.y = PasswordErrorLabel.frame.origin.y + uiVgap  + uiHeight
        PasswordErrorLabel.frame.origin.x = PasswordTextField.frame.origin.x
        //PasswordErrorLabel.textAlignment = .center
        PasswordErrorLabel.textColor = .red
        PasswordErrorLabel.text = "**Wrong Password or Email"
        view.addSubview(PasswordErrorLabel)
        
        let LogInSignUpButton = UIButton ()
        LogInSignUpButton.frame = CGRect (x: 40, y: topMargin * 5, width: width  - margin * 4, height: 60)
        //LogInButton.center = CGPoint (x: 40, y: topMargin * 4)
        LogInSignUpButton.setTitle("LOGIN", for: .normal)
        LogInSignUpButton.backgroundColor = .darkGray
        LogInSignUpButton.tintColor = .black
        LogInSignUpButton.layer.cornerRadius = 8.0
        LogInSignUpButton.layer.borderWidth = 2
        LogInSignUpButton.layer.borderColor = UIColor.black.cgColor
        view.addSubview(LogInSignUpButton)
        
        
        let changeModeButton = UIButton ()
        changeModeButton.frame = CGRect (x: 40, y: topMargin * 9, width: width - margin * 6, height: 60)
        changeModeButton.setTitle("New User? SignUp Now for Free", for: .normal)
        changeModeButton.setTitleColor (UIColor.black, for: .normal)
        //changeModeButton.tintColor = .blue
        //changeModeButton.titleColor(for: .normal)
        view.addSubview(changeModeButton)
        
        /*
        func LogInSignUpButton(_ sender: UIButton) {
            
            if UserNameTextField == nil
            {
                self.performSegue(withIdentifier: "Type Something", sender: nil)
                
            }
            else {
                
                let alert = UIAlertController(title: "Sorry", message:"You have to SignUp First", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default) { _ in })
                self.present(alert, animated: true){}
            }
            
        }

        
        
        var mode:Int = 1
        
        func LogInSignUpButton (_ sender: UIButton) {
            
        }
        
        
        func changeModeButton (_ sender: UIButton!) {
            
            if mode == 0 {
                mode = 1
                LogInSignUpButton.setTitle("SignUp", for: .normal)
                changeModeButton.setTitle("Already Register? Login Now", for: .normal)
            }
            else if mode == 1 {
                mode = 0
                LogInSignUpButton.setTitle("LogIn", for: .normal)
                changeModeButton.setTitle("New User? SignUp", for: .normal)
            }
        }
        */
        
        
        // Construct Button
        
        //add IBAction alike addTarget
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
