//
//  ViewController.swift
//  BasicCodeUIHw
//
//  Created by Emily-Khine Chu on 8/9/18.
//  Copyright © 2018 Emily-Khine Chu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        //usernametextfield
        view.backgroundColor = UIColor.blue
        var userNameTextField = UITextField(frame: CGRect(x: 55, y: 100, width: 300, height: 40))
        userNameTextField.backgroundColor = UIColor.white
        view.addSubview(userNameTextField)
        
        //username Error message
        
        var userNameErrorMsg = UILabel(frame: CGRect(x: 55, y: 150, width: 200, height: 30))
        userNameErrorMsg.text = "Invalid username"
        userNameErrorMsg.textColor = UIColor.white
        view.addSubview(userNameErrorMsg)
      
        
        //passwordtextfield
        var pwdTextField = UITextField(frame: CGRect(x: 55, y: 220, width: 300, height: 40))
        pwdTextField.backgroundColor = UIColor.white
        view.addSubview(pwdTextField)
        
        
        
        //pwd Error message
        var pwdErrorMsg = UILabel(frame: CGRect(x: 55, y: 270, width: 200, height: 30))
        pwdErrorMsg.text = "Invalid password"
        pwdErrorMsg.textColor = UIColor.white
        pwdTextField.isSecureTextEntry = true
        view.addSubview(pwdErrorMsg)
        
        
        
        //Login Sign up Button
        
        var loginSignupBtn = UIButton(frame: CGRect(x: 55, y: 340, width: 300, height: 80))
        loginSignupBtn.setTitle("Log in", for: .normal)
        loginSignupBtn.backgroundColor = UIColor.green
        //loginSignupBtn.addTarget(self, action: click , for: UIControlEvents.touchUpInside)
        view.addSubview(loginSignupBtn)
        
     /* func click(sender: UIButton!) {
            print("clicked")
        }
       */
        
        
        
        //registered log in new user sign up button
        var changeModeBtn = UIButton(frame: CGRect(x: 55, y: 640, width: 300, height: 40))
        changeModeBtn.setTitle("new user? sign up", for: .normal)
        changeModeBtn.backgroundColor = UIColor.green
        //changeModeBtn.addTarget(self, action: "click" , for: .touchUpInside)
        view.addSubview(changeModeBtn)
        //func click(sender: UIButton!) {
        //    print("clicked")
       // }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

