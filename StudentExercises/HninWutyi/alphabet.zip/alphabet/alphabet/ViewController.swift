//
//  ViewController.swift
//  alphabet
//
//  Created by Hnin Wutyi on 9/7/18.
//  Copyright © 2018 Hnin Wutyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var btnA: UIButton!
    @IBOutlet weak var btnB: UIButton!
    @IBOutlet weak var btnC: UIButton!
    @IBOutlet weak var btnD: UIButton!
    @IBOutlet weak var btnE: UIButton!
    @IBOutlet weak var btnF: UIButton!
    @IBOutlet weak var btnG: UIButton!
    @IBOutlet weak var btnH: UIButton!
    @IBOutlet weak var btnI: UIButton!
    @IBOutlet weak var btnJ: UIButton!
    @IBOutlet weak var btnK: UIButton!
    @IBOutlet weak var btnL: UIButton!
    @IBOutlet weak var btnM: UIButton!
    @IBOutlet weak var btnN: UIButton!
    @IBOutlet weak var btnO: UIButton!
    @IBOutlet weak var btnP: UIButton!
    @IBOutlet weak var btnQ: UIButton!
    @IBOutlet weak var btnR: UIButton!
    @IBOutlet weak var btnS: UIButton!
    @IBOutlet weak var btnT: UIButton!
    @IBOutlet weak var btnU: UIButton!
    @IBOutlet weak var btnV: UIButton!
    @IBOutlet weak var btnW: UIButton!
    @IBOutlet weak var btnX: UIButton!
    @IBOutlet weak var btnY: UIButton!
    @IBOutlet weak var btnZ: UIButton!
    
    @IBOutlet weak var btnS2: UIButton!
    @IBOutlet weak var btnS1: UIButton!
    
    @IBOutlet weak var animalLabel: UILabel!
    @IBOutlet weak var alphabetLbl: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    var datas:[String:String] = ["A":"Antelope",
                                 "B":"Bat",
                                 "C":"Cow",
                                 "D":"Dog",
                                 "E":"Eagle",
                                 "F":"Falcon",
                                 "G":"Giraffe",
                                 "H":"Horse",
                                 "I":"Iguana",
                                 "J":"Jaguar",
                                 "K":"Kangaroo",
                                 "L":"Lion",
                                 "M":"Monkey",
                                 "N":"Numbat",
                                 "O":"Otter",
                                 "P":"Parrot",
                                 "Q":"Quetzal",
                                 "R":"Rat",
                                 "S":"Sheep",
                                 "T":"Tiger",
                                 "U":"Urial",
                                 "V":"Vicuna",
                                 "W":"Wildebeest",
                                 "X":"Xenons",
                                 "Y":"Yak",
                                 "Z":"Zebra"]
    
    @IBAction func showData(_ sender: UIButton) {
        for (key, value) in datas{
            if(key == sender.titleLabel?.text){
                alphabetLbl.text = key
                animalLabel.text = value
                imageView.image = UIImage(named: key + ".png")
            }
        }
    }
    func changeButtonApperance(){
        let mycolor = UIColor(red: 38/255, green: 124/255, blue: 61/255, alpha: 0.7)
        let btns:[UIButton] = [btnA,btnB,btnC,btnD,btnE,btnF,btnG,btnH,btnI,btnJ,btnK,btnL,btnM,btnN,btnO,btnP,btnQ,btnR,btnS,btnT,btnU,btnV,btnW,btnX,btnY,btnZ,btnS1,btnS2]
        for i in btns{
            i.layer.cornerRadius = i.layer.frame.height / 2
            i.backgroundColor = mycolor
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        changeButtonApperance()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

