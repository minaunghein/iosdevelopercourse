//
//  ViewController.swift
//  hninShoppingMall
//
//  Created by Hnin Wutyi on 8/15/18.
//  Copyright © 2018 Hnin Wutyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var burgerPrice:Double = 3000
    var pizzaPrice:Double = 24000
    var donutPrice:Double = 1500
    var cakePrice:Double = 2000
    var coffeePrice:Double = 2000
    var teaPrice:Double = 1500
    var icecreamPrice:Double = 2500
    var standwitchPrice:Double = 2500
    var juicePrice:Double = 1500
    var buyItem:String = ""
    var totalPrice:Double = 0

    @IBOutlet weak var totalPriceLabel: UILabel!
    @IBOutlet weak var itemLabel: UILabel!
    @IBOutlet weak var dateTimeLabel: UILabel!
    @IBOutlet weak var burgerButton: UIButton!
    @IBOutlet weak var donutButton: UIButton!
    @IBOutlet weak var pizzaButton: UIButton!
    @IBOutlet weak var cakeButton: UIButton!
    @IBOutlet weak var standwitchButton: UIButton!
    @IBOutlet weak var coffeeButton: UIButton!
    @IBOutlet weak var juiceButton: UIButton!
    @IBOutlet weak var iceCreamButton: UIButton!
    @IBOutlet weak var teaButton: UIButton!
    @IBOutlet weak var buyButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        totalPriceLabel.text = "Total price\t\t0"
       
    }
   
    @IBAction func buyBurger(_ sender: Any) {
      //  burgerCount += 1
        buyItem += "Burger\t\t\t\(burgerPrice)\n"
        totalPrice += burgerPrice
        itemLabel.text = buyItem
    }
    @IBAction func buyPizza(_ sender: Any) {
       // pizzaCount += 1
        buyItem += "Pizza\t\t\t\(pizzaPrice)\n"
        totalPrice += pizzaPrice
        itemLabel.text = buyItem
    }
    @IBAction func buyDonut(_ sender: Any) {
       // donutCount += 1
        buyItem += "Donut\t\t\t\(donutPrice)\n"
        totalPrice += donutPrice
        itemLabel.text = buyItem
    }
    @IBAction func buyTea(_ sender: Any) {
        buyItem += "Tea\t\t\t\t\(teaPrice)\n"
        totalPrice += teaPrice
        itemLabel.text = buyItem
    }
    @IBAction func buyCoffee(_ sender: Any) {
        buyItem += "Coffee\t\t\t\(coffeePrice)\n"
        totalPrice += coffeePrice
        itemLabel.text = buyItem
    }
    @IBAction func buyCake(_ sender: Any) {
        buyItem += "Cake\t\t\t\(cakePrice)\n"
        totalPrice += cakePrice
        itemLabel.text = buyItem
    }
    @IBAction func buyIceCream(_ sender: Any) {
        buyItem += "Ice-Cream\t\t\(icecreamPrice)\n"
        totalPrice += icecreamPrice
        itemLabel.text = buyItem
    }
    @IBAction func buyStandwitch(_ sender: Any) {
        buyItem += "Standwitch\t\(standwitchPrice)\n"
        totalPrice += standwitchPrice
        itemLabel.text = buyItem
    }
    @IBAction func buyJuice(_ sender: Any) {
        buyItem += "Juice\t\t\t\(juicePrice)\n"
        totalPrice += juicePrice
        itemLabel.text = buyItem
    }
    @IBAction func buy(_ sender: Any) {
        totalPriceLabel.text = "Total price\t\t\(totalPrice)"
    }
    override func didReceiveMemoryWarning() {
       
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}

