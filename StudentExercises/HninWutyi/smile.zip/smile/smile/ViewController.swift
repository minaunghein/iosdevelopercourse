//
//  ViewController.swift
//  smile
//
//  Created by Hnin Wutyi on 8/6/18.
//  Copyright © 2018 Hnin Wutyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        view.backgroundColor = UIColor.black
        
        let mylabel = UILabel(frame: CGRect(x: 10, y: 50, width: 200, height: 80))
        mylabel.text = "Have a nice day. Have fun!"
        mylabel.lineBreakMode = .byWordWrapping
        mylabel.textAlignment = .center
        mylabel.textColor = UIColor.white
        mylabel.font = UIFont(name: "Tahoma", size: 30)
        mylabel.frame.size = CGSize(width: 200, height: 80)
        mylabel.center = CGPoint(x: view.frame.size.width / 2, y: 100)
        let faceWidth = CGFloat(200.0)
        let faceHeight = CGFloat(200.0)
        
        let xPos = view.frame.size.width/2 - 100
        let yPos = view.frame.size.height/2 - 100
        
        let xPosLeye = xPos/2 - 10
        let xPosReye = xPos + xPos/2 - 30
        let mouthWidth = xPosReye - xPosLeye - 20
       
        let face = UIView(frame: CGRect(x: xPos, y: yPos, width: faceWidth, height: faceHeight))
        face.backgroundColor = UIColor.white
        face.layer.cornerRadius = CGFloat(100)
        
        let earL = UIView(frame: CGRect(x: xPos-20, y: yPos, width: 60, height: 60))
        earL.backgroundColor = UIColor.white
        earL.layer.cornerRadius = CGFloat(30)
        
        let earR = UIView(frame: CGRect(x: xPos + 160, y: yPos , width: 60, height: 60))
        earR.backgroundColor = UIColor.white
        earR.layer.cornerRadius = CGFloat(30)
        
        let eye1 = UIView(frame: CGRect(x: xPosLeye, y: yPos/4, width: 25, height: 25))
        eye1.backgroundColor = UIColor.black
        eye1.layer.cornerRadius = CGFloat(13)
        face.addSubview(eye1)
        
       // let eye2 = UIView(frame: CGRect(x: xPos*1.2, y: yPos/4, width: 20, height: 20))
        let eye2 = UIView(frame: CGRect(x: xPosReye, y: yPos/4, width: 25, height: 25))
        eye2.backgroundColor = UIColor.black
        eye2.layer.cornerRadius = CGFloat(13)
        face.addSubview(eye2)
        
        let mouth = UIView(frame: CGRect(x: xPos/2 + 10, y: yPos/4 + 60 , width: mouthWidth, height: 10))
        mouth.backgroundColor = UIColor.black
        mouth.layer.cornerRadius = CGFloat(5)
        
        let tongue = UIView(frame: CGRect(x: xPos - 5 , y: yPos/4 + 60 , width: 20, height: 25))
        tongue.backgroundColor = UIColor.black
        tongue.layer.cornerRadius = CGFloat(10)
        
        face.addSubview(tongue)
        face.addSubview(mouth)
        view.addSubview(earL)
        view.addSubview(earR)
        view.addSubview(face)
        view.addSubview(mylabel)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

