//
//  ViewController.swift
//  programmerLife
//
//  Created by Hnin Wutyi on 8/7/18.
//  Copyright © 2018 Hnin Wutyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        view.backgroundColor = UIColor.gray
        let frameWidth = view.frame.size.width
        let frameHeight = view.frame.size.height
        
        let bldWidth = frameWidth/3
        let bldHeight = frameHeight/4*3
        
        let bldLayer = UIView(frame: view.frame)
        let skyLayer = UIView(frame: view.frame)
        let bldWindowLayer = UIView(frame: view.frame)
        
        //let moonX = frameWidth - 70 - frameWidth/3
        //let moonY = frameHeight/4 - 70
        
        
        let bldY = frameHeight - bldHeight
        let moonX = bldWidth*2 - 70
        let moonY = bldY - 70
        
        let bld1 = UIView(frame: CGRect(x: 0, y: bldY, width: bldWidth, height: bldHeight))
        bld1.backgroundColor = UIColor.black
        
        let bld2 = UIView(frame: CGRect(x: bldWidth, y: frameHeight/3, width: bldWidth/2, height: frameHeight - frameHeight/3))
        bld2.backgroundColor = UIColor.black
        
        let bld3 = UIView(frame: CGRect(x: bldWidth*2, y: bldY, width: bldWidth, height: bldHeight))
        bld3.backgroundColor = UIColor.black
        
        let windows = UIView(frame: CGRect(x: bldWidth*2 + 10, y: bldY + 10 , width: 20, height: 20))
        windows.backgroundColor = UIColor.yellow
        
        let moon = UIView(frame: CGRect(x: moonX, y: moonY, width: 100, height: 100))
        moon.backgroundColor = UIColor.white
        moon.layer.cornerRadius = 50
        
        skyLayer.addSubview(moon)
        bldLayer.addSubview(bld2)
        bldLayer.addSubview(bld3)
        bldLayer.addSubview(bld1)
        bldWindowLayer.addSubview(windows)
        
        view.addSubview(skyLayer)
        view.addSubview(bldLayer)
        view.addSubview(bldWindowLayer)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

