//
//  ViewController.swift
//  basicUIs
//
//  Created by Min Aung Hein on 8/6/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let margin:CGFloat =  20
    
    //Load one time - use for initialise
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        
        let width = view.frame.size.width
        let height =  view.frame.size.height
         let borderWidth:CGFloat = 40

        //Drag n drop => addSubView
        let view100 = UIView(frame: CGRect(x:0,y:0,width:width * 2 / 3,height:height * 2/3))
        view100.backgroundColor = UIColor.green
        view100.tag = 100
        view100.alpha =  0.4
        
        view.addSubview(view100)
       
        let view100LineBox = UIView(frame: CGRect(x:view100.frame.size.width + margin  ,y:-borderWidth ,width:width   / 3 - margin + borderWidth ,height:height  / 3 - margin + borderWidth ))
        view100LineBox.layer.borderWidth = borderWidth
        view100LineBox.layer.borderColor = view100.backgroundColor?.cgColor
        view100LineBox.backgroundColor = UIColor.clear
        //view100LineBox.alpha =  0.4
        view.addSubview(view100LineBox)
        
        let view200 = UIView(frame: CGRect(x:width/3,y:height/3,width:width * 2 / 3,height:height * 2/3))
        view200.backgroundColor = UIColor.blue
        view200.tag = 200
         view200.alpha =  0.4
        view.addSubview(view200)
        
        let view200LineBox = UIView( frame:CGRect(x: -borderWidth , y:height - view100LineBox.frame.size.height + borderWidth ,width: view100LineBox.frame.size.width ,height:view100LineBox.frame.size.height ))
        view200LineBox.layer.borderWidth = borderWidth
        view200LineBox.layer.borderColor = view200.backgroundColor?.cgColor
        view200LineBox.backgroundColor = UIColor.clear
        //view200LineBox.alpha =  0.4
        view.addSubview(view200LineBox)
        
        let view300 = UIView(frame: CGRect(x:width   / 3 + margin,y: height  / 3 + margin ,width: width  / 3 - margin * 2,height:height / 3 - margin * 2 ))
        view300.layer.borderColor =  UIColor.white.cgColor
        view300.layer.borderWidth = borderWidth / 2
        view300.backgroundColor = UIColor.clear
        view300.tag = 300
        view.addSubview(view300)
        
        let lineWidth = borderWidth / 2
        let circleMargin:CGFloat = 5
        let circleWidth = view300.frame.size.width - lineWidth  * 2 - circleMargin * 2
        let circle = UIView(frame: CGRect(x:view300.frame.size.width / 2 -  circleWidth / 2    ,y:view300.frame.size.height / 2  -  circleWidth / 2 ,width:     circleWidth,height:circleWidth  ))
        circle.backgroundColor = UIColor.green
       //circle.alpha = 0.6
        circle.tag = 300
        circle.layer.cornerRadius =  circle.frame.size.width / 2
        view300.addSubview(circle)
    
    }


}

