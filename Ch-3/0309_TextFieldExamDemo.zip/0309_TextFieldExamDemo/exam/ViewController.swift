//
//  ViewController.swift
//  exam
//
//  Created by Min Aung Hein on 27/10/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usermarkTextField: UITextField!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var gradeLabel: UILabel!
    
    
    @IBAction func checkResult(_ sender: UIButton) {
        
        //guard expecttruecondition else { return }
        
        guard usermarkTextField.text != nil && usermarkTextField.text != "" else {
            return
        }
        
        usermarkTextField.resignFirstResponder()
        let markStr = usermarkTextField.text
        let mark:Float = Float( markStr ?? "0" ) ?? 0
        
        if mark < 40 {
            statusLabel.text = "Failed"
        }
        else {
            statusLabel.text = "Passed"
            
            if mark <= 60 {
                gradeLabel.text = "Grade C"
            }
            else if mark <= 80 {
                gradeLabel.text = "Grade B"
            }
            else {
                gradeLabel.text = "Grade A"
            }
        }
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

