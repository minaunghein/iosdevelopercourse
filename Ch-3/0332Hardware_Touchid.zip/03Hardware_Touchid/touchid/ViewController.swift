//
//  ViewController.swift
//  touchid
//
//  Created by Min Aung Hein on 5/11/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit
import LocalAuthentication

class ViewController: UIViewController {

    @IBAction func check(_ sender:UIButton){
        
        let ca = LAContext()
        var error:NSError?
        do {
            
            let status = try ca.canEvaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, error: nil   )
            
            let reason = "Testing TouchID"
            ca.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { (status, e) in
                if e != nil {
                    print(e?.localizedDescription)
                } else {
                    if status {
                        print("Confirmed!")
                    } else {
                        print("Biometric failed try again")
                    }
                }
                
            }
        }catch var error as Error {
            print("No Biometric supported")
            print(error.localizedDescription)
        }
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

