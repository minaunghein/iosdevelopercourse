//
//  ViewController.swift
//  bootPC
//
//  Created by Min Aung Hein on 8/13/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//
//MVC
import UIKit

class ViewController: UIViewController {

    var index = 0
    var messageLabel:UILabel! // ! will be allocate lately before used
    var message = ""
    //M
    var messages = ["Checking NVRam", "Checking ROMBIOS", "Checking IDE1.0", "Checking IDE2.0","Loading OS","Loading Windows"]
    
        //view is default view created by ViewControler
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let width = view.frame.size.width
        let height = view.frame.size.height
        
        let labelFrame = CGRect(x: 10, y: 20, width: width - 20 , height: 20)
       messageLabel = UILabel(frame:labelFrame)
        
        messageLabel.textColor = UIColor.white
        messageLabel.numberOfLines = 0
        messageLabel.lineBreakMode  = .byWordWrapping
        
        
       view.addSubview(messageLabel)

       print( messageLabel.intrinsicContentSize) //actual size to be display
        
        view.backgroundColor = UIColor.black
        
        let btnView = UIView(frame: CGRect(x: 0, y: height - 100, width: width, height: 100))
        btnView.backgroundColor = UIColor.white
        
        view.addSubview(btnView)
        let margin:CGFloat = 50
        let topMargin:CGFloat = 20
        let btn = UIButton(frame: CGRect(x: margin, y: topMargin, width: width -  margin * 2, height: 100 -  topMargin * 2 ))
        btnView.addSubview(btn)
        
        
        btn.setTitle("Boot", for: .normal)
        btn.backgroundColor = UIColor.green
        
        btn.addTarget(self, action: #selector( check), for: .touchUpInside)
        
        
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { (t) in
            self.check(UIButton())
        }
         
    }

    
    //C
    @objc func check(_ sender:UIButton ){
        
        if  index <  messages.count {
            message = message +  messages[index] + " . . .\n"
            messageLabel.text = message
            index += 1
            messageLabel.frame.size.height += 20
        }
    }

}

