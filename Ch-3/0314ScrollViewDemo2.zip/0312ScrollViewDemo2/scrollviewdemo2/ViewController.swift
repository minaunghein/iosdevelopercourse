//
//  ViewController.swift
//  scrollviewdemo2
//
//  Created by Min Aung Hein on 16/10/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {

    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageCtrl: UIPageControl!
    
    var images = ["image1.jpg","image2.jpg","image3.jpg","image4.jpg","image5.jpg"]
    var numPage:CGFloat = 0
    
    
    @IBAction func selectPage(_ sender: UIPageControl) {
        
        print(sender.currentPage)
        let imgWidth = view.frame.size.width
        let imgHeight = view.frame.size.height
        let stx = CGFloat(sender.currentPage) *  imgWidth
        let pageRect = CGRect(x: stx, y: 0, width: imgWidth, height: imgHeight)
        scrollView.scrollRectToVisible(pageRect, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        pageCtrl.currentPage = Int( scrollView.contentOffset.x /   view.frame.size.width)
    }
    
    func addImage(imageStr:String) {
        
        let imgWidth = view.frame.size.width
        let imgHeight = view.frame.size.height
        let stx = numPage *  imgWidth
        let sty:CGFloat = scrollView.frame.origin.y
        let imageView = UIImageView(frame: CGRect(x: stx, y: sty, width: imgWidth, height: imgHeight))
        imageView.image = UIImage(named:imageStr)
        
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        
        numPage += 1
        scrollView.addSubview(imageView)
        scrollView.isPagingEnabled = true 
        scrollView.contentSize = CGSize(width: numPage * imgWidth , height: imgHeight)
        pageCtrl.numberOfPages = Int( numPage )
    }
    
    override func viewWillAppear(_ animated: Bool) {
       
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollView.delegate = self //***
        for i in images {
            addImage(imageStr: i)
        }
        
        //TEST
        /*
        pageCtrl.numberOfPages = Int(numPage)
        let width = view.frame.size.width * numPage
        let height = scrollView.frame.size.height
        
        scrollView.contentSize = CGSize(width: width, height: height)
        */
        
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { (t) in
             var currentPage = self.pageCtrl.currentPage
             currentPage += 1
            if currentPage < self.images.count {
                self.pageCtrl.currentPage = currentPage
                self.selectPage(self.pageCtrl)
            }
            else {
                currentPage = 0
                self.pageCtrl.currentPage = currentPage
                self.selectPage(self.pageCtrl)
            }
        }
        
        
        
        
    }


}

