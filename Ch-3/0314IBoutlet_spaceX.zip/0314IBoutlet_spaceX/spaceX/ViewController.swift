//
//  ViewController.swift
//  spaceX
//
//  Created by Min Aung Hein on 4/11/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var launchBtn: UIButton!
    @IBOutlet weak var rocketImageView: UIImageView!
    
    let secretCode = "3175"
    var userEnterCode = ""
    var originalRocketY:CGFloat = 0
    
    @IBAction func press1(_ sender: UIButton) {
        userEnterCode += "1"
        checkAuth()
    }
    @IBAction func press3(_ sender: UIButton) {
       userEnterCode += "3"
        checkAuth()
    }
    @IBAction func press5(_ sender: UIButton) {
        userEnterCode += "5"
        checkAuth()
    }
    @IBAction func press7(_ sender: UIButton) {
        userEnterCode += "7"
        checkAuth()
    }
    
    @IBAction func Reset(_ sender: Any) {
        userEnterCode = ""
    }
    
    @IBAction func pressLaunch(_ sender: Any) {
        launchRocket()
    }
    
    func checkAuth(){
        let status =  checkAuth(para1: secretCode, para2: userEnterCode)
        if status {
            launchReady()
        }
    }
    
    func checkAuth(para1:String, para2:String)-> Bool {
        return para1 == para2
    }
    func launchRocket() {
        print("Launching...")
        //print(rocketImageView.frame.origin.x,rocketImageView.frame.origin.y,rocketImageView.frame.size.height )
        
        
       // rocketImageView.frame.origin.y = -rocketImageView.frame.size.height
        //TODO: make animation moving rocket
        originalRocketY = self.rocketImageView.frame.origin.y
        UIView.animate(withDuration: 2.0, animations: {
            self.rocketImageView.frame.origin.y = -self.rocketImageView.frame.size.height
        }) { (status) in
            self.restart()
        }
    }
    func launchReady() {
        
        OperationQueue.main.addOperation {
             self.launchBtn.isEnabled = true
        }
    }
    
    func restart() {
        userEnterCode = ""
        launchBtn.isEnabled = false
        rocketImageView.alpha = 0
        rocketImageView.frame.origin.y = originalRocketY
        UIView.animate(withDuration: 3) {
             self.rocketImageView.alpha = 1.0
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

