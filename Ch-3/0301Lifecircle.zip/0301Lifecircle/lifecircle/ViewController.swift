//
//  ViewController.swift
//  lifecircle
//
//  Created by Min Aung Hein on 10/11/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("View did load")
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewWillAppear(_ animated: Bool) {
         print("View will appear")
    }
    
    override func viewDidAppear(_ animated: Bool) {
         print("View did appear")
        //Post  processing
    }
    override func viewWillDisappear(_ animated: Bool) {
         print("View will disappear")
    }
    override func viewDidDisappear(_ animated: Bool) {
         print("View did disappear")
    }

}

