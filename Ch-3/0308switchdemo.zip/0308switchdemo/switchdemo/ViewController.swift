//
//  ViewController.swift
//  switchdemo
//
//  Created by Min Aung Hein on 6/1/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let sw1 = UISwitch()
        let sw2 = UISwitch()
        let sw3 = UISwitch()
        let sw4 = UISwitch()
        
        sw1.center = CGPoint(x: 120, y: 150)
        sw2.center = CGPoint(x: 120, y: 200)
        sw3.center = CGPoint(x: 120, y: 250)
        sw4.center = CGPoint(x: 120, y: 350)
        
        view.addSubview(sw1)
        view.addSubview(sw2)
        view.addSubview(sw3)
        view.addSubview(sw4)
        
    }


}

