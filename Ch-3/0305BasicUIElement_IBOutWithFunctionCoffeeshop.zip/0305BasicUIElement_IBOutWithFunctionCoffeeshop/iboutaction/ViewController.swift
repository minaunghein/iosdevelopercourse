//
//  ViewController.swift
//  iboutaction
//
//  Created by Min Aung Hein on 13/10/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var numCup:Int = 0 //camel
    
    @IBOutlet weak var coffeeCupLabel: UILabel! //Noun
    //use to control user interface element by code
    
    @IBOutlet weak var incBtn: UIButton! //Noun
    @IBOutlet weak var decBtn: UIButton! //Noun
    
    
    
    @IBAction func increase(_ sender: UIButton) {
        numCup += 1
        update()
    }
    
    @IBAction func decrease(_ sender: UIButton) {
        if numCup > 0 {
            numCup -= 1
        }
        update()
    }
    func update(){
        coffeeCupLabel.text = "# " + String(  numCup )
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        update()
    }


}

