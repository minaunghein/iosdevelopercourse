//
//  ViewController.swift
//  segmentdemo1
//
//  Created by Min Aung Hein on 6/1/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let seg1 = UISegmentedControl(items: ["One","Two","Three","Four"])
        seg1.frame = CGRect(x: 40, y: 40, width: view.frame.size.width - 80, height: 60)
        
        view.addSubview(seg1)
    }


}

