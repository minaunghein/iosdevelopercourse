//
//  ViewController.swift
//  picturegallery
//
//  Created by Min Aung Hein on 25/3/17.
//  Copyright © 2017 smag. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	var photoIndex = 0
	var imagesString = ["marvel02","marvel01","marvel03","marvel04","marvel05","marvel06","marvel07","marvel08","marvel09","marvel10"]
	
	@IBOutlet weak var galleryImageView: UIImageView!
	
	func updateImage() {
		let image = UIImage(named: imagesString[photoIndex])
		galleryImageView.image = image
	}
	
	@IBAction func goBack(_ sender: UIButton) {
		
		if photoIndex > 0
		{
			photoIndex -= 1
			updateImage()
		}
	}
	
	@IBAction func goForward(_ sender: UIButton) {
		
		if photoIndex < (imagesString.count - 1 )
		{
			photoIndex += 1
			updateImage()
		}
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		photoIndex = 0
		updateImage()
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

