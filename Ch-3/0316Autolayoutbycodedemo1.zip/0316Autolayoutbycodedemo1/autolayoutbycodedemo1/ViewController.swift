//
//  ViewController.swift
//  autolayoutbycodedemo1
//
//  Created by Min Aung Hein on 29/12/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var const1:NSLayoutConstraint!
    var const2:NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        let view1 = UIView()
        view1.backgroundColor = UIColor.green
        view.addSubview(view1) //1
        view1.translatesAutoresizingMaskIntoConstraints = false //2
        //type 1 Applied
        view1.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        view1.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        view1.topAnchor.constraint(equalTo: view.topAnchor, constant: 20).isActive = true
        view1.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -200).isActive = true
        
        let viewSquare = UIView()
        viewSquare.backgroundColor = UIColor.red
        view.addSubview(viewSquare) //1
        viewSquare.translatesAutoresizingMaskIntoConstraints = false //2
        viewSquare.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        viewSquare.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        const1 = viewSquare.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.2)
        viewSquare.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.2).isActive = true
        const2 = viewSquare.widthAnchor.constraint(equalToConstant: 300)
        const1.isActive = true
        
        let button = UIButton()
        button.backgroundColor = UIColor.purple
        view.addSubview(button)
        button.setTitle("Click Me", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        button.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20).isActive = true
        button.addTarget(self, action: #selector(click), for: .touchUpInside)
        
        let viewYellow = UIView()
        viewYellow.backgroundColor = UIColor.yellow
        viewYellow.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(viewYellow)
        viewYellow.leadingAnchor.constraint(equalTo: viewSquare.leadingAnchor, constant: 20).isActive = true
        viewYellow.trailingAnchor.constraint(equalTo: viewSquare.trailingAnchor, constant: 20).isActive = true
        viewYellow.topAnchor.constraint(equalTo: view1.bottomAnchor, constant: 20).isActive = true
        viewYellow.bottomAnchor.constraint(equalTo: button.topAnchor, constant: -20).isActive = true 
        
        
    }

    @objc func click(_ sender:UIButton){
        const1.isActive = const2.isActive
        const2.isActive = !const1.isActive
        
    }
}

