//
//  ViewController.swift
//  buttondemo1
//
//  Created by Min Aung Hein on 6/1/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let margin:CGFloat = 20.0
    let topMargin:CGFloat = 100.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let button1 = UIButton(frame: CGRect(x: margin, y: topMargin, width: 200, height: 100))
        button1.setTitle("Click Me", for: .normal)
        button1.backgroundColor = UIColor.green
        view.addSubview(button1)
        
         
        button1.setTitle("Clicked", for: .highlighted)
        
        
    }


}

