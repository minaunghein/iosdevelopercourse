//
//  ViewController.swift
//  stepperdemo1
//
//  Created by Min Aung Hein on 6/1/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let stepper1 = UIStepper()
        stepper1.center = CGPoint(x: view.frame.size.width / 2, y: 80)
        view.addSubview(stepper1)
    }


}

