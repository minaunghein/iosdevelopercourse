//
//  ViewController.swift
//  imageviewdemo1
//
//  Created by Min Aung Hein on 17/11/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var pictureView:UIImageView! //allocate later before use
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       // let picFrame = CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height)
        let width = view.frame.size.width
        let height = view.frame.size.height
        
        let viewFrame = view.frame
        self.pictureView = UIImageView(frame: viewFrame)
        pictureView.image = UIImage(named: "lady")//scale to fill
        pictureView.contentMode = .scaleAspectFill
        pictureView.clipsToBounds = true
        
        
        let label = UILabel()
        label.text = "Professional Look for Women @Taw Win Centre-2PM Saturday"
        
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        
        label.textColor = UIColor.white
        label.textAlignment = .center
        
        view.addSubview(pictureView)
        view.addSubview(label)
        let margin:CGFloat = 20
        let labelFrame = CGRect(x: margin, y: height / 2, width: width - margin * 2, height: label.intrinsicContentSize.height )
        
        label.frame = labelFrame
        label.sizeToFit()
        
        
        let button = UIButton()  // L-20, bot-20,r-20, h-100
        button.setTitle("Enter", for: .normal)
        button.setTitle("Welcome", for: .highlighted)
        
        button.backgroundColor = UIColor.red
        let buttonFrame = CGRect(x: 20, y: height - 100 - 20 , width: width - 40, height: 100 )
        button.frame = buttonFrame
        
        button.layer.cornerRadius = 10
        
        button.addTarget(self , action: #selector(clickEnter), for: .touchUpInside)
        view.addSubview(button)
        
        let sw1 = UISwitch()
        sw1.onTintColor =  button.backgroundColor
        sw1.frame.origin = CGPoint(x: width - 20 - sw1.frame.size.width , y: button.frame.origin.y - 10 - sw1.frame.size.height )
        sw1.addTarget(self , action: #selector(changeValue), for: .valueChanged)
        view.addSubview(sw1)
        
        let stepper = UIStepper()
        stepper.minimumValue = 0
        stepper.maximumValue = 1
        stepper.stepValue = 0.1
        stepper.value = Double(pictureView.alpha)
        
        let stepperFrame = CGRect(x: width / 2 - stepper.intrinsicContentSize.width / 2   , y: 50, width: 0, height: 0)
        stepper.frame = stepperFrame
        //stepper.tintColor = UIColor.green
        stepper.addTarget(self, action: #selector(changeStepperValue), for: .valueChanged)
        view.addSubview(stepper)
    }
    @objc func changeStepperValue(_ sender:UIStepper) {
        pictureView.alpha  = CGFloat(sender.value)
    }
    @objc func changeValue(_ sender:UISwitch){
        print("switched ! \(sender.isOn)")
    }
    @objc func clickEnter(_ sender:UIButton){
       print("You are welcome")
    }
}

