//
//  MyTableViewCell3.swift
//  Collection
//
//  Created by Min Aung Hein on 15/10/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class MyTableViewCell3: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
