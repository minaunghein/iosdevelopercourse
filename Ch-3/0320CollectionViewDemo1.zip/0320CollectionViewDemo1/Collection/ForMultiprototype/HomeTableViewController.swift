//
//  HomeTableViewController.swift
//  Collection
//
//  Created by Min Aung Hein on 15/10/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 10
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellreuseid = "mycell1"
        if indexPath.row == 0 {
            cellreuseid = "mycell1"
        }
        else if indexPath.row == 1 || indexPath.row == 2  {
            cellreuseid = "mycell2"
        }
        else if indexPath.row == 3{
          cellreuseid  = "mycell1"
        }
        else  {
            cellreuseid  = "mycell3"
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: cellreuseid    )
        return cell!
    }
    

}
