//
//  ViewController.swift
//  basicUI2
//
//  Created by Min Aung Hein on 8/7/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let textLayer = UIView(frame: view.frame)
        let picLayer = UIView(frame:view.frame)
        
        let label = UILabel()
        label.textColor = UIColor.white
        label.text = "Welcome"
        label.frame.size = CGSize(width: 200, height: 80)
        label.frame.origin.x = view.center.x - label.frame.size.width / 2
        label.frame.origin.y = 50
        
        label.textAlignment = .center
        //label.font = UIFont.systemFont(ofSize: 28)
        label.font = UIFont.boldSystemFont(ofSize: 28)
        //label.font = UIFont(name: "Zawgyi-One", size: 28)
         textLayer.addSubview(label)
        
        let imageView = UIImageView()
        imageView.frame.size  = view.frame.size
        imageView.image = UIImage(named: "pic")
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        
        picLayer.addSubview(imageView)
       
        
        view.addSubview(picLayer    )
        view.addSubview(textLayer)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

