//
//  ViewController.swift
//  labeldemo1
//
//  Created by Min Aung Hein on 6/1/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let label = UILabel()
        label.frame = CGRect(x:10,y:20,width:200,height:80)
        label.text = "This is label"
        label.textColor = UIColor.green
        //label.font = UIFont.systemFont(ofSize: 40)
        print(label.intrinsicContentSize)
        view.addSubview(label)
    }


}

