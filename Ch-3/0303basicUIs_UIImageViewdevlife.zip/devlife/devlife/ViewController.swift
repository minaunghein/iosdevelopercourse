//
//  ViewController.swift
//  devlife
//
//  Created by Min Aung Hein on 8/7/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var width:CGFloat = 0
    var height:CGFloat = 0
    var buildingColor = UIColor.gray
    var userTouchedY:CGFloat = 0
    var alphaRatio:CGFloat = 1.0
    let roadHeight:CGFloat = 5
    var darkLayer:UIView!
    var buildingLayer:UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        width = view.frame.size.width
        height = view.frame.size.height
        alphaRatio =  0.7 / height
        
        
        
        
        let roadLayer = UIView(frame: CGRect(x: 0, y: height - roadHeight, width: width, height: roadHeight))
         buildingLayer = UIView(frame:view.frame)
        let skyLayer = UIView(frame:view.frame)
        skyLayer.backgroundColor = UIColor.white
        
        darkLayer = UIView(frame:view.frame)
        darkLayer.backgroundColor = UIColor.darkGray
        darkLayer.alpha = 0.0
        skyLayer.addSubview(darkLayer)
        
        //addBuilding one
        let h1 =  height * 5 / 6
        let buildingWidth =  width / 4
        let building1 = UIView(frame: CGRect(x: 0, y: height - h1, width: buildingWidth, height: h1))
        building1.backgroundColor = buildingColor
        building1.addWindows()
        buildingLayer.addSubview(building1)
        
        //addBuilding two
        let h2 =  height * 4 / 6
        let building2 = UIView(frame: CGRect(x: building1.frame.size.width, y: height - h2, width: buildingWidth, height: h2))
        building2.addWindows()
        building2.backgroundColor = buildingColor
        buildingLayer.addSubview(building2)
        
        //addBuilding two
       let h3 =  height * 4.5 / 6
        let building3 = UIView(frame: CGRect(x: width - building1.frame.size.width, y: height - h3, width: buildingWidth, height: h3))
        building3.backgroundColor = buildingColor
        building3.addWindows()
        buildingLayer.addSubview(building3)
        
        //add red and white block to roadlayer
        for i in 0...10 {
            let block = UIView(frame: CGRect(x:CGFloat(i) * roadLayer.frame.width / 10 ,y:0,width: width / 10 , height:roadHeight))
            block.backgroundColor =  i % 2 == 0 ? UIColor.darkGray : UIColor.red
            roadLayer.addSubview(block)
        }
        
        //create sky
        let moonWidth = width / 3
        let margin = width / 10
        let moon = UIView(frame: CGRect(x: building3.frame.origin.x -  moonWidth / 2 , y: building3.frame.origin.y - moonWidth / 2 , width: moonWidth, height: moonWidth))
        moon.backgroundColor = UIColor.white
        moon.layer.cornerRadius = moonWidth /  2
        skyLayer.addSubview(moon)
        skyLayer.addGradient()
        
        view.addSubview(skyLayer)
        view.addSubview(buildingLayer)
        view.addSubview(roadLayer)
        
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(makeLight))
        view.addGestureRecognizer(panGestureRecognizer)
        
        
        runDog()
    }

   @objc func makeLight(_ panGestureRecognizer:UIPanGestureRecognizer) {
    if panGestureRecognizer.state == .began {
            userTouchedY = panGestureRecognizer.location(in: view).y
    } else if panGestureRecognizer.state == .changed    {
            let changedY = panGestureRecognizer.location(in: view).y
            let diff =  ( userTouchedY - changedY ) * alphaRatio
            self.darkLayer.alpha =     -diff
    }
    
    //decide as per the night worker level
    for subView in buildingLayer.subviews   {
        for window in subView.subviews {
            if window.tag == 0 && self.darkLayer.alpha > 0.3 {
                UIView.animate(withDuration: 0.5) {
                     window.backgroundColor =  self.buildingColor
                }
                
            }
            else if window.tag == 1 && self.darkLayer.alpha > 0.4 {
                UIView.animate(withDuration: 0.5) {
                    window.backgroundColor =  self.buildingColor
                }
            }
           else if window.tag == 2 && self.darkLayer.alpha >= 0.6 {
                UIView.animate(withDuration: 0.5) {
                    window.backgroundColor =  self.buildingColor
                }
              
            }
        }
    }
    if panGestureRecognizer.state == .ended {
        
        for subView in buildingLayer.subviews   {
            for window in subView.subviews {
                window.backgroundColor = UIColor.white
            }
        }
        resetDay()
    }
    
   
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    func resetDay() {
        self.darkLayer.alpha = 0.0
    }
    
    func runDog() {
        let dog =  Dog()
        dog.imageView.startAnimating()
        dog.imageView.frame.origin.x = -dog.imageView.frame.width
        dog.imageView.frame.origin.y = height   - dog.imageView.frame.height + 10
        
        
        UIView.animate(withDuration: 5, animations: {
             dog.imageView.frame.origin.x = self.width
        }) { (s) in
            
              dog.imageView.frame.origin.x = -dog.imageView.frame.width
             self.runDog()  
        }
        view.addSubview(dog.imageView)
    }

}


extension UIView {
    func addGradient() {
        let gradient: CAGradientLayer = CAGradientLayer()
        
        gradient.colors = [UIColor.orange.cgColor, UIColor.white.cgColor]
        gradient.locations = [-0.50 , 0.3]
        gradient.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradient.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradient.frame = CGRect(x: 0.0, y: 0.0, width:  self.frame.size.width, height:  self.frame.size.height)
        
        self.layer.insertSublayer(gradient, at: 0)
        
       
        
    }
    func addWindows( ) {
        
        let cols:CGFloat = 3
        let margin:CGFloat =  10
        let gap:CGFloat = 20
        let windowWidth =  ( self.frame.size.width  - margin * 2 - gap * ( cols - 1 )) / cols
        let totalRow = Int( self.frame.size.height / windowWidth / 2 )
        for k in 0..<totalRow - 5 {
            for j in 0..<Int(cols) {
                let window = UIView(frame: CGRect(x:margin + CGFloat(j) * windowWidth + CGFloat(j) * gap,y: margin + CGFloat(k) * windowWidth + CGFloat(k) * gap, width: windowWidth, height:windowWidth  ))
                self.addSubview(window)
                window.tag = Int( arc4random_uniform(2))
                window.backgroundColor =  UIColor.white
                
            }
        }
        
            self.subviews[Int(arc4random_uniform(UInt32(self.subviews.count)))].tag = 2
        
        
    }
}

class Dog{
    var imageView = UIImageView()
    init( ) {
        imageView.animationImages = Array(0...15).map({ index in
            return UIImage(named:"frame_\(index)_delay-0.04s.png")!
        })
        imageView.frame.size = CGSize(width: 100, height: 80)
    }
}
