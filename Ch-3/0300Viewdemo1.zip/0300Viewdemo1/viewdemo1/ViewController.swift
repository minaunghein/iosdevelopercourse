//
//  ViewController.swift
//  viewdemo1
//
//  Created by Min Aung Hein on 11/11/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.green
        //self.view.backgroundColor = UIColor.init(red: 0.5, green: 0, blue: 0, alpha: 1)
        
        let width = self.view.frame.size.width
        let height = self.view.frame.size.height
        
        //1. UIxxxxxxxxz
        //2. add to parent view with 'addSubView'
        let f1 = CGRect(x: 20, y: 60, width: width / 2, height: height / 2 )
        let v1 = UIView(frame:f1 )
        v1.backgroundColor = UIColor.white
        self.view.addSubview(v1)
        
    }


}

