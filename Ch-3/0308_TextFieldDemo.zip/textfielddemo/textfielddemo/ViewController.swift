//
//  ViewController.swift
//  textfielddemo
//
//  Created by Min Aung Hein on 6/11/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var textField1: UITextField!
    @IBOutlet weak var textField2: UITextField!
    
    @IBOutlet weak var textField3: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        textField1.delegate = self
        textField2.delegate = self
        textField3.delegate = self
        
 
    }
    
    @IBAction func tapView(_ sender: UITapGestureRecognizer) {
        
        view.endEditing(true )
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == textField1 && textField2.text == "" {
            textField2.becomeFirstResponder()
        }else if textField == textField2  && textField3.text == "" {
            textField3.becomeFirstResponder()
        }else  if textField == textField3 {
            textField.resignFirstResponder()
        }else {
            textField.resignFirstResponder()
        }
        
         return true
    }
    


}

