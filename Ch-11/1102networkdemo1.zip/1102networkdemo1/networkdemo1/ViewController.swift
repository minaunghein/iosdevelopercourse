//
//  ViewController.swift
//  networkdemo1
//
//  Created by Min Aung Hein on 5/11/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

//GET, POST , PUT , DELETE

class ViewController: UIViewController {

    let endPointURLString = "https://forex.cbm.gov.mm/api/latest"
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var rateLabel: UILabel!
    
    
    @IBAction func getRate(_ sender: UIButton) {
        
        let endPointURL = URL(string: endPointURLString)!
        let request =  URLRequest(url:endPointURL)
        //URLSession
        let session = URLSession(configuration:URLSessionConfiguration.default)
        let task = session.dataTask(with: request) { (data, response, error) in
        
            if error == nil && data != nil {
                
                //Convert data to dictionary
                do {
                    
                    let dataDict = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:Any]
                    print(dataDict)
                    if let timeString = (dataDict?["timestamp"] as?  String) {
                        OperationQueue.main.addOperation {
                            
                            let dateValue  = Double(timeString) ?? 0.0
                            let date = Date.init(timeIntervalSince1970: dateValue)
                            let dateString = String(describing: date)
                            
                            self.dateLabel.text = "Date: \(dateString)"
                        }
                        
                    }
                    if let rates = dataDict?["rates"] as? [String:Any] {
                        
                        let usd = rates["USD"] as? String ?? "0.0"
                        print(usd)
                        OperationQueue.main.addOperation {
                            self.rateLabel.text = "USD Rate: \(usd)"
                        }
                    }

                } catch let error {
                    print("Fail to convert to dictionary")
                    print(error.localizedDescription)
                }
            }else {
                print(error?.localizedDescription)
            }
            
        }
        task.resume()//****
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

