//
//  ViewController.swift
//  networkdemo2
//
//  Created by Min Aung Hein on 5/12/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultTextView: UITextView!
    @IBOutlet weak var idTextField: UITextField!
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var authorTextField: UITextField!
    
    let baseURLString = "http://192.168.100.60:3000/"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func deletePost(_ sender: UIButton) {
        
        guard let id = idTextField.text , id != "" else  {
            print("Invalid id ")
            return
        }
        
        let postURLString = baseURLString + "posts/" + id
        let postURL = URL(string: postURLString)!
        var request = URLRequest(url:postURL)
        request.httpMethod = "DELETE"
        let session =  URLSession(configuration:URLSessionConfiguration.default)
        let task =  session.dataTask(with: request) { (data, response, error) in
            if error == nil  {
                if let data = data {
                    do {
                        let postDict = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                        print(postDict)
                        let string = String.init(data: data, encoding: .utf8)
                        OperationQueue.main.addOperation {
                            self.resultTextView?.text =  string
                        }
                    } catch let error {
                        debugPrint(error.localizedDescription)
                    }
                }
            } else {
                debugPrint(error?.localizedDescription)
            }
        }
        task.resume()
        
        
    }
    
    @IBAction func pustPost(_ sender: Any) {
        
        guard let id = idTextField.text , id != "" else  {
            print("Invalid id ")
            return
        }
        
        guard let title = titleTextField.text , title != "" else  {
            print("Invalid title")
            return
        }
        
        guard let author = authorTextField.text , author != "" else  {
            print("Invalid author")
            return
        }
        
        let postURLString = baseURLString + "posts/" + id
        let postURL = URL(string: postURLString)!
        var request = URLRequest(url:postURL)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let postDict = [ "title": title, "author":author]
        let bodydata = try! JSONSerialization.data(withJSONObject: postDict, options: .prettyPrinted)
        request.httpBody = bodydata
        //let headers = [ "Content-Type":"application/json","Authorization":"Bearer xxxxxxxxx"]
        //request.allHTTPHeaderFields = headers
        
        
        let session =  URLSession(configuration:URLSessionConfiguration.default)
        let task =  session.dataTask(with: request) { (data, response, error) in
            if error == nil  {
                if let data = data {
                    do {
                        let postDict = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                        print(postDict)
                        let string = String.init(data: data, encoding: .utf8)
                        OperationQueue.main.addOperation {
                            self.resultTextView?.text =  string
                        }
                    } catch let error {
                        debugPrint(error.localizedDescription)
                    }
                }
            } else {
                debugPrint(error?.localizedDescription)
            }
        }
        task.resume()
    }
    
    @IBAction func patchPost(_ sender: Any) {
        
        guard let id = idTextField.text , id != "" else  {
            print("Invalid id ")
            return
        }
        
        let title = titleTextField.text
        let author = authorTextField.text
        
        
        let postURLString = baseURLString + "posts/" + id
        let postURL = URL(string: postURLString)!
        var request = URLRequest(url:postURL)
        request.httpMethod = "PATCH"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        var postDict:[String:String] = [String:String]()
        
        if title != nil  && title != "" {
            postDict =  [ "title": title! ]
        }
        if author != nil && author != ""  {
            postDict =  [ "author": author! ]
        }
        
        let bodydata = try! JSONSerialization.data(withJSONObject: postDict, options: .prettyPrinted)
        request.httpBody = bodydata
       
        
        let session =  URLSession(configuration:URLSessionConfiguration.default)
        let task =  session.dataTask(with: request) { (data, response, error) in
            if error == nil  {
                if let data = data {
                    do {
                        let postDict = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                        print(postDict)
                        let string = String.init(data: data, encoding: .utf8)
                        OperationQueue.main.addOperation {
                            self.resultTextView?.text =  string
                        }
                    } catch let error {
                        debugPrint(error.localizedDescription)
                    }
                }
            } else {
                debugPrint(error?.localizedDescription)
            }
        }
        task.resume()
    }
    
    @IBAction func createPost(_ sender: Any) {
        
        let postURLString = baseURLString + "posts"
        let postURL = URL(string: postURLString)!
        var request = URLRequest(url:postURL)
        request.httpMethod = "POST" 
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let postDict = [ "title": "Super Late Sunday", "author":"min aung hein"]
        let bodydata = try! JSONSerialization.data(withJSONObject: postDict, options: .prettyPrinted)
        request.httpBody = bodydata
        //let headers = [ "Content-Type":"application/json","Authorization":"Bearer xxxxxxxxx"]
        //request.allHTTPHeaderFields = headers
        
        
        let session =  URLSession(configuration:URLSessionConfiguration.default)
        let task =  session.dataTask(with: request) { (data, response, error) in
            if error == nil  {
                if let data = data {
                    do {
                        let postDict = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                        print(postDict)
                        let string = String.init(data: data, encoding: .utf8)
                        OperationQueue.main.addOperation {
                            self.resultTextView?.text =  string
                        }
                    } catch let error {
                        debugPrint(error.localizedDescription)
                    }
                }
            } else {
                debugPrint(error?.localizedDescription)
            }
        }
        task.resume()
    }
    
    @IBAction func getPost(_ sender: Any) {
        let postID = idTextField.text
        let postURLString = postID == nil ?   baseURLString + "posts" : baseURLString + "posts/" + postID!
        let postURL = URL(string: postURLString)!
        let request = URLRequest(url:postURL)
        let session =  URLSession(configuration:URLSessionConfiguration.default)
        let task =  session.dataTask(with: request) { (data, response, error) in
            if error == nil  {
                if let data = data {
                    do {
                        let postDict = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                        print(postDict)
                        let string = String.init(data: data, encoding: .utf8)
                        OperationQueue.main.addOperation {
                            self.resultTextView?.text =  string
                        }
                    } catch let error {
                        debugPrint(error.localizedDescription)
                    }
                }
            } else {
                debugPrint(error?.localizedDescription)
            }
        }
        task.resume()
    }
    
}

