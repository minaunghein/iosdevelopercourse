//
//  VC1.swift
//  noticenter
//
//  Created by Min Aung Hein on 27/8/17.
//  Copyright © 2017 smag. All rights reserved.
//

import UIKit
 
class VC1: UIViewController {

  
    override func viewDidLoad() {
        super.viewDidLoad()
			mynoti = NotificationCenter()

			}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
	@IBAction func firevc1(_ sender: UIButton) {



		NotificationCenter.default.post(name: Notification.Name(rawValue:"vc1event"), object: ["hey":"Greeting"])

	}
	override func viewDidAppear(_ animated: Bool) {

		print("VC1 loaded")
		let nameofnoti = Notification.Name(rawValue: "vc1event")

		NotificationCenter.default.addObserver(forName: nameofnoti, object: self, queue: OperationQueue.main) { ( noti ) in

			var data = noti.object
			var a = noti.userInfo
			print("In vc1 event")
			
		}



	}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    override func viewWillAppear(_ animated: Bool) {
        
	}
}
