//
//  VC3.swift
//  noticenter
//
//  Created by Min Aung Hein on 27/8/17.
//  Copyright © 2017 smag. All rights reserved.
//

import UIKit
import NotificationCenter

class VC3: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func fire(_ sender: UIButton) {


		let data:[String:Any] = ["mode":1,"msg":"Time to update"]
        let notiname = Notification.Name(rawValue: "vc1event")

     // NotificationCenter.default.post(name: notiname, object: self, userInfo: data)

		NotificationCenter.default.post(name: notiname, object: data)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
