//
//  ViewController.swift
//  notification
//
//  Created by Min Aung Hein on 5/16/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        addUI()
        addObserver()
    }
    
    func addUI(){
        
        let textField = UITextField()
        textField.tag = 1 // id eg. RRT41
        view.addSubview(textField)
        textField.frame = CGRect(x: 20, y:  80, width: view.frame.size.width - 40 , height: 60)
        textField.backgroundColor = UIColor.white
        
        let button = UIButton()
        view.addSubview(button)
        button.frame = CGRect(x: 20, y: 330, width: view.frame.size.width - 40 , height: 60)
        button.setTitle("Notify", for: .normal)
        button.backgroundColor = UIColor.purple
        button.addTarget(self, action: #selector(commandParser), for: .touchUpInside)
        //XMLButton
        
    }
    
    
    @objc func commandParser(_ sender:UIButton){
        print("Calling by btn")
        let btnNoti = Notification.Name.init("RRT001")
        
        NotificationCenter.default.post(name: btnNoti, object: ("RRB001","D"))
    }
    
    func addObserver(){
        
        let textFieldNoti = Notification.Name.init("RRT001")
        NotificationCenter.default.addObserver(self, selector: #selector(responseCommand), name: textFieldNoti, object: nil)
    }
    @objc func  responseCommand(_ noti:Notification){
        print("Calling textField...")
        let param = noti.object as? (String,String )
        
        
    }
}

