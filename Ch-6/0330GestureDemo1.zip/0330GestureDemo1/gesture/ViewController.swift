//
//  ViewController.swift
//  gesture
//
//  Created by Min Aung Hein on 17/10/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var counterLabel: UILabel!
    var counter = 0
    
    
    func update(){
        counterLabel.text = String(counter)
    }
    
    
    @IBAction func countUp(_ sender: UITapGestureRecognizer) {
        counter += 1
        update()
    }
    
    @IBAction func countDown(_ sender: UISwipeGestureRecognizer) {
        
        if counter > 0 {
        counter -= 1
        update()
        }
        
    }
    
    var oldScale:CGFloat = 0
    
    let thrDeg:CGFloat = 30.0
    var oldDeg:CGFloat = 0.0
    
    @IBAction func countUp50(_ sender: UIRotationGestureRecognizer) {
        print("Rotating...")
        
        let deg = sender.rotation * CGFloat(180.0 / Double.pi)
        print(deg)
        if (deg - oldDeg) > thrDeg { //threshold over?
            counter += 50
            oldDeg = deg //*** //UPDATE IT
        }
        else if ( deg - oldDeg ) < -thrDeg && counter >= 50 {
            
            counter -= 50
            oldDeg = deg  //set no different
        }
        if sender.state == .ended {
            oldDeg = 0.0
        }
        update()
    }
    
    @IBAction func countUpTen(_ sender: UIPinchGestureRecognizer) {
        print("In pinch...")
        var symbol = 1
        guard sender.state != .ended else {
            return 
        }
        if sender.state == .began {
            oldScale = sender.scale
        } else if  sender.scale <  oldScale {
                
            symbol = -1
        }
        oldScale = sender.scale
        counter += (symbol) * 10
        if counter < 0 {
            counter = 0
        }
        update()
        
    }
    
    @IBAction func reset(_ sender: UILongPressGestureRecognizer) {
        
        counter = 0
        update()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        update()
        //Add swipe up gesture
        let gesture = UISwipeGestureRecognizer()
        gesture.direction = .up
     view.addGestureRecognizer(gesture)
        gesture.addTarget(self, action: #selector(countUpFive))
    }
    
  @objc  func countUpFive(_ sender: UISwipeGestureRecognizer) {
        counter += 5
        update()
    }


}

