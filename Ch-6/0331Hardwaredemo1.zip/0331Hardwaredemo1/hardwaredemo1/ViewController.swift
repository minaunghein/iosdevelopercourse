//
//  ViewController.swift
//  hardwaredemo1
//
//  Created by Min Aung Hein on 30/10/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit
import MobileCoreServices

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var picture: UIImageView!
    let imagePicker = UIImagePickerController()
    
    let imageMediaType = kUTTypeImage as String
    let movieMediaType = kUTTypeMovie as String
    
    @IBAction func pick(_ sender: UIButton) {
        
        let alertCtrlr = UIAlertController(title: "From source", message: "Select the picture source", preferredStyle: .alert)
        
        
        let actionCamera = UIAlertAction(title: "Camera", style: .default) { (action) in
            self.pickFromCamera()
        }
        
        let actionLibrary = UIAlertAction(title: "Library", style: .default, handler: libraryHandler)
        
        alertCtrlr.addAction(actionCamera)
        alertCtrlr.addAction(actionLibrary)
        
        present(alertCtrlr, animated: true, completion: nil)
        
        
    }
    
    func libraryHandler(_ action:UIAlertAction)  {
        pickFromLibrary()
    }
    
    //Camera & Photo Library Accessing
    func pickFromCamera() {
        imagePicker.sourceType = .camera
        imagePicker.allowsEditing = true
        imagePicker.cameraFlashMode = .on
        //**** NSMicrophoneUsageDescription
        imagePicker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .camera)!
        present(imagePicker, animated: true, completion: nil)
    }
    func pickFromLibrary() {
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = true
        
        
        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
        print("User cancel")
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let typeOfMedia = info[.mediaType] as! String
        print(typeOfMedia)
        switch typeOfMedia {
        case movieMediaType: let tempVideoPath = info[.mediaURL] as? URL
        
        UISaveVideoAtPathToSavedPhotosAlbum((tempVideoPath?.path)!, self, #selector(video(_:didFinishSavingWithError:contextInfo:)),nil)
            
        case imageMediaType: let image = info[.editedImage] as? UIImage
        picture.image = image
        print("User did shoot / Video")
        //image(_:didFinishSavingWithError:contextInfo:)
        UIImageWriteToSavedPhotosAlbum(image!, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
        default:()
            
        }
        picker.dismiss(animated: true, completion: nil )
        
        
    }
    
    @objc func video(_ video: String, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if error == nil {
            print("Saved")
        }
        else {
            print(error?.localizedDescription)
        }
    }
    
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if error == nil {
            print("Saved")
        }
        else {
            print(error?.localizedDescription)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        imagePicker.delegate = self //****
    }
    
    
}

