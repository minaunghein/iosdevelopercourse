//
//  File.swift
//  alertNow
//
//  Created by Min Aung Hein on 29/4/17.
//  Copyright © 2017 smag. All rights reserved.
//

import Foundation

//Each question is a dictionary , in which you can extract info by using its key-> Q, A,CA
var currentQuestion = 0
var score = 0
let q1:[String:Any] = [ "Q":"What is the keyword to create a variable as a constant?",
							"A":[ "var","let","Int","for"  ],
							"CA":1
	]
let q2:[String:Any] = [ "Q":"We use these keyword for looping:",
                        "A":[ "break","let","Int","for"  ],
                        "CA":3
	
				]
let q3:[String:Any] = [ "Q":"We use these keyword for creating integer variable:",
                        "A":[ "double","float","Int","Bool"  ],
                        "CA":2
]

let questions = [ q1,q2,q3]









