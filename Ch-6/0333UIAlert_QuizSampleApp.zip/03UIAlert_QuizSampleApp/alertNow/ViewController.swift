//
//  ViewController.swift
//  alertNow
//
//  Created by Min Aung Hein on 29/4/17.
//  Copyright © 2017 smag. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	var question:[String:Any]!

	@IBOutlet weak var questionCountLabel: UILabel!
	@IBOutlet weak var questionLabel: UILabel!
	@IBAction func showAlert(_ sender: UIButton) {

		let  alertCtrl = UIAlertController(title: "Choice", message: self.question["Q"] as! String,
		                                   preferredStyle: .actionSheet)
		let answers = self.question["A"] as! [String]

		//Extract actions from answer array
		for answer in answers {

			let action1 = UIAlertAction(title: answer, style: .default) { (action) in

				//Increase to next question
				currentQuestion += 1

				if currentQuestion == questions.count { //end of question
						self.performSegue(withIdentifier: "resultvc", sender: nil)
				}
				else {
					 self.update()
				}

			}

				alertCtrl.addAction(action1)
		} // end of for
		//add extra cancel
		let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
		}

		alertCtrl.addAction(cancelAction)
		self.present(alertCtrl, animated: true, completion: nil)
	}


	func update() {
		self.questionCountLabel.text = "Q \(currentQuestion + 1)"
		self.question = questions[currentQuestion]
		self.questionLabel.text = self.question["Q"] as! String

	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
		self.questionCountLabel.text = "Q \(currentQuestion + 1)"
		self.question = questions[currentQuestion]
		self.questionLabel.text = self.question["Q"] as! String

		

	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

