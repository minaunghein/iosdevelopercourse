//
//  ViewController.swift
//  tableviewdemo1
//
//  Created by Min Aung Hein on 29/12/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
    
    //3 Facts - Section? , Row? , Cell?
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2000000
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"cell1")!
        cell.textLabel?.text = "Row \(indexPath.row + 1)"
        cell.accessoryType = .none 
        if indexPath.row < 10 {
            cell.backgroundColor = UIColor.cyan
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         print(indexPath.row)
        tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

