//
//  AccountRealm.swift
//  ocbcbank
//
//  Created by Min Aung Hein on 11/28/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import Foundation
import RealmSwift

class Account:  Object {
    @objc dynamic var id =   UUID().uuidString
    @objc dynamic var username:String = ""
    @objc dynamic var password:String = ""
    let minimumAmt = 1000.0
    @objc dynamic var amount:Double = 0
    
    
    //Methods
    func save(_ amt:Double)->Bool{
        //TODO Load SQLite
        guard amt > 0 else {
            return false
        }
        
        let frid = self.id
        let toid = self.id
        let op = "s"
        let created = Date().timeIntervalSinceReferenceDate
       //Write realm code here
        
        refresh()
        return true
    }
    
    func refresh() {
        updateAmount { (amt, status) in
            self.amount = amt
        }
    }
    
    func withdraw(_ amt:Double)->Bool {
        
        //TODO Load SQLite
        guard (amt    <= ( self.amount  - minimumAmt )) else {
            return false
        }
        
        let frid = self.id
        let toid = self.id
        let op = "w"
        let created = Date().timeIntervalSinceReferenceDate
          //Write realm code here
        
        refresh()
        return true
        
    }
    func transfer(_ amt:Double,toid:UInt)-> Bool {
        //TODO Load SQLite
        guard (amt    <= ( self.amount  - minimumAmt )) else {
            return false
        }
        
        let frid = self.id
        let toid = toid
        let op = "t"
        let created = Date().timeIntervalSinceReferenceDate
        //Write realm code here
        
         refresh( )
        return true
    }
    
    func getTransactions()-> [(dateStr:String, trTypeStr:String, amtStr:String)] {
        var transacs = [(dateStr:String, trTypeStr:String, amtStr:String)] ()
         //Write realm code here
        
        return transacs
    }
    
    func getTransactions(startDate:Date,endDate:Date){
        
    }
    
    func getAmount()->Double {
        return amount
    }
    
    func updateAmount( callback:  (Double, Bool    )->( )    ) {
        var totalAmt = 0.0
        //Write realm code here
        
       /* if  let rows = sqlManager?.query(sql: "SELECT  *  FROM Transac WHERE frid = \(self._id) OR  toid = \(self._id)" ) {
            for row in rows {
                
                //  let id = row["tid"] as! Int
                var  amt = row["amt"] as! Double
                let frid = row["frid"] as! Int
                //   let toid = row["toid"] as! Int
                let op = row["op"] as! String
                if op == "w" || ( op == "t" && frid == self.id ) {
                    amt = -amt
                }
                totalAmt +=  amt
                
            }
            callback(totalAmt, true)
            return
        }*/
        callback(0,false )
    }
    
    
    
    
    
    
    
 

}
