//
//  HomeViewController.swift
//  ocbcbank
//
//  Created by Min Aung Hein on 8/25/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var amountLabel: UILabel!
    
    
    var currentAccount:Account! 
    @IBAction func logout(_ sender: UIBarButtonItem) {
        
        navigationController?.dismiss(animated: true , completion: nil)
    }
    
    
   
    @IBAction func Saving(_ sender: UIButton) {
        performSegue(withIdentifier: "savingsegue", sender: currentAccount)
    }
    
    
    @IBAction func Withdraw(_ sender: UIButton) {
        performSegue(withIdentifier: "withdrawsegue", sender: currentAccount)
    }
    
    @IBAction func Transfer(_ sender: UIButton) {
        performSegue(withIdentifier: "transfersegue", sender: currentAccount)
    }
    
    @IBAction func History(_ sender: UIButton) {
        performSegue(withIdentifier: "historysegue", sender: currentAccount)
    }
    
    @IBAction func Info(_ sender: UIButton) {
        performSegue(withIdentifier: "infosegue", sender: currentAccount)
    }
    
    @IBAction func About(_ sender: UIButton) {
        performSegue(withIdentifier: "aboutsegue", sender: currentAccount)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier ?? " "{
            
        case "savingsegue": let savingVC = segue.destination as? SavingViewController
            savingVC?.account = sender as? Account
        case "withdrawsegue": let withdrawVC = segue.destination as? WithdrawViewController
        withdrawVC?.account = sender as? Account
        case "transfersegue": let transferVC = segue.destination as? TransferViewController
        transferVC?.account = sender as? Account
        case "historysegue": let historyVC = segue.destination as? HistoryViewController
        historyVC?.account = sender as? Account
            
        default:break;
            
        }
    }
   
    
    override func viewWillAppear(_ animated: Bool) {
         currentAccount.refresh()
    }
    override func viewDidAppear(_ animated: Bool) {
        amountLabel.text = String( currentAccount.getAmount() )
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
