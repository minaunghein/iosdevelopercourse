//
//  HistoryViewController.swift
//  ocbcbank
//
//  Created by Min Aung Hein on 8/25/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class HistoryViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var account:Account!
    var transacs = [(dateStr:String,trTypeStr:String,amtStr:String)] ()
    
    func getData() {
        transacs = account.getTransactions()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return transacs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "trcell") as? HistoryTableViewCell
        let currentTransac = transacs[indexPath.row]        
        cell?.dateLabel.text = currentTransac.dateStr
        cell?.trTypeLabel.text = currentTransac.trTypeStr
        cell?.amountLabel.text = currentTransac.amtStr
        return cell!
        
    }
    
    @IBOutlet weak var tabelView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

         getData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
