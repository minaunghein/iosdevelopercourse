//
//  DBCreatorViewController.swift
//  ocbcbank
//
//  Created by Min Aung Hein on 11/28/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit
import RealmSwift
class DBCreatorViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("Your local realm here:")
        print(FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!)
        do {
            let realm = try Realm()
            let admin = AccountRealm()
            admin.username = "admin"
            admin.password = "password"
            
            let user1 = AccountRealm()
            user1.username = "user1"
            user1.password = "user1"
            
            let user2 = AccountRealm()
            user2.username = "user2"
            user2.password = "user2"
            
            let user3 = AccountRealm()
            user3.username = "user3"
            user3.password = "user3"
            
            try! realm.write {
                realm.add([admin,user1,user2,user3])
            }
        } catch let error {
            print(error.localizedDescription)
        }
        
        
      
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
