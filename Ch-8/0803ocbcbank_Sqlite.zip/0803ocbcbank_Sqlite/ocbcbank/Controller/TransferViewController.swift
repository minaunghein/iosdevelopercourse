//
//  TransferViewController.swift
//  ocbcbank
//
//  Created by Min Aung Hein on 8/25/18.
//  Copyright © 2018 Min Aung Hein. All rights reserved.
//

import UIKit

class TransferViewController: UIViewController {
    
    var account:Account!
    
    
    @IBOutlet weak var amountTextField: UITextField!
    
    @IBOutlet weak var accountTextField: UITextField!
    
    @IBAction func Transfer(_ sender: UIButton) {
        
        
        guard let amount = amountTextField.text, amount != "", let value = Double(amount), value > 0.0 else {
            return
            
        }
        
        guard let ac = accountTextField.text, ac != "", let toid = UInt(ac) else {
            return
        }
        
        let bank = Bank()
        if bank.isAccountExist(id: toid){          
       
        
        let status = account.transfer(value, toid:toid)
        print(status)
        if status {
            amountTextField.text = ""
            account.refresh()
        }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
